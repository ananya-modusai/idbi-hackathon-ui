# Modus UI Boilerplate

A standalone Next.js + Tailwind + shadcn/ui package that reproduces the app
shell, design-system components, and visual language of the production app,
so a demo UI can be built that looks and feels like the real product without
needing access to the real codebase (which has business logic, API clients,
and Zustand stores that don't make sense outside that repo).

## What's in here

```
app/
  layout.tsx          Root layout — fonts + globals.css
  globals.css         Exact colour tokens (HSL CSS vars) from the real app
  page.tsx            Landing page, links to /demo
  demo/page.tsx        <-- the one working screen (see below)
components/
  ui/                 shadcn/ui primitives — copied verbatim from the real app
                       (button, badge, table, tabs, input, select, card,
                       sidebar, popover, checkbox, avatar, sheet, tooltip,
                       separator, skeleton)
  custom/             The app's own design-system layer, built on top of ui/
    PageHeader.tsx      Blue title + [TYPE id] chip + copy button + actions
    StatCard.tsx        KPI tile (icon, label, value, optional trend arrow)
    BubbleTag.tsx        Status-pill/badge used for NPA status, risk tiers, etc.
    ToggleTabs.tsx       Compact segmented control (e.g. Table/Chart)
    FilterBar.tsx        Multi-select filter with count chips (NEW — see below)
    DataTable.tsx         Generic sortable table wrapper (NEW — see below)
    RightPanel.tsx        Collapsible right-hand panel (NEW — see below)
    DemoForm.tsx          react-hook-form + zod form pattern (NEW — see below)
    CustomCard.tsx / CustomColorScheme.tsx   shared primitives other components use
  layout/             The app shell
    AppShell.tsx         Composes sidebar + topbar + content column
    AppSidebar.tsx        Collapsible nav sidebar, "modus ai" wordmark
    AppTopbar.tsx          Breadcrumb header (Group > Item > Tab)
    Workspace.tsx           The one-card-per-page content wrapper + tab bar
    WorkspaceTabBar.tsx
    WorkspaceContent.tsx
    WorkspaceContext.tsx    Minimal React Context standing in for the real
                            app's Zustand workspace store
    UserProfileFooter.tsx   Bottom-of-sidebar user chip
hooks/use-mobile.tsx  Sidebar mobile breakpoint hook
lib/utils.ts          `cn()` class-merge helper
```

## Setup

```bash
npm install
npm run dev
```

Opens on **http://localhost:3010** (picked to avoid colliding with other
local Next.js apps on 3000/3001/3002). Visit `/demo` for the working screen.

## The one working screen: `/demo`

`app/demo/page.tsx` is a "Lead Prioritization" screen that exercises every
component in this package in one place:

- `AppShell` — sidebar + topbar + gray content area
- `Workspace` with **two tabs** (Overview / Notes) — proves the tab-bar contract
- `PageHeader` with a title, ID chip, and an action button
- A row of 4 `StatCard`s (including one with a trend arrow, one with a themed
  colour)
- `FilterBar` (multi-select risk-tier filter with count chips) next to a
  `ToggleTabs` (Table/Chart switch)
- `DataTable` — sortable columns, `BubbleTag` status badges colour-coded by
  risk tier
- `RightPanel` — collapsible right-hand panel with a suggested-action card
- A toggleable `DemoForm` (react-hook-form + zod) to show the create/edit
  form pattern

All data on the page is a small in-file fixture array (`LEADS`) — swap it for
a real API call and the rest of the page (filtering, sorting, badges) keeps
working unchanged.

## Design tokens

- **Colour system**: HSL CSS variables in `app/globals.css`
  (`--primary`, `--sidebar-background`, `--chart-1..5`, etc.), consumed via
  `tailwind.config.ts`. This is copied byte-for-byte from the real app —
  changing these variables re-themes every component at once.
- **Style**: shadcn/ui "new-york" variant, zinc base colour
  (`components.json`).
- **Icons**: [lucide-react](https://lucide.dev) throughout.
- **Radius**: `--radius: 0.75rem`, exposed as `rounded-lg`/`rounded-md`/`rounded-sm`.
- **Wordmark**: sidebar logo is `"modus ai"` in Montserrat 800 at `#00285B`.

### Fonts

The real app uses local Geist woff files for body text. This boilerplate
uses **Inter** via `next/font/google` instead (`app/layout.tsx`) so the
package has zero binary asset dependencies and works immediately after
`npm install`. Visually very close to Geist; swap back to Geist/your brand
font by editing `app/layout.tsx` if pixel-exact typography matters.

## Deviations from production (read before treating this as "the real app")

This is a **visual/structural boilerplate**, not an extraction of the real
codebase. A few things were deliberately simplified so it stands alone with
no API clients, auth, or state-management wiring:

- **`WorkspaceContext.tsx`** is a small React Context, not the real app's
  Zustand `workspaceStore`. Same shape/contract (`activeNavigation`,
  `activeTab`, tab refresh), swap the implementation for Zustand/Redux/etc.
  once you're wiring up real navigation.
- **`FilterBar.tsx`** and **`DataTable.tsx`** are new, simplified
  components. The real app's `MultiSelectFilterBar` (602 lines) and
  `CustomTableView` (1,275 lines) additionally support `cmdk`-based combobox
  search, CSV export, column pinning, and virtualization for large datasets.
  These lighter versions match the **visual language exactly** (label +
  pill dropdown + count chips; sortable header + zebra rows) but not every
  feature — fine for a demo, not a drop-in replacement.
- **`AppSidebar.tsx`** ships 3 example nav groups instead of the real app's
  full (and business-specific) navigation tree. The nav *model* (group →
  items with icon + active state) is identical — just repopulate
  `sidebarGroups`.
- **`AppShell.tsx`** composes `SidebarProvider` + sidebar + topbar + content
  in one place. In the real app's current deployment this particular
  build only renders a single merchant report page and doesn't mount the
  sidebar at all — this boilerplate wires the shell together the way the
  underlying primitives are designed to be used, which is the more useful
  reference for building a full multi-page demo.
- **`PageHeader.tsx`** drops the `framer-motion` fade-in and the
  "Create AI Report" chat integration from the production version — just
  the header layout remains.
- A couple of tiny upstream bugs were fixed rather than copied: `Input`'s
  base width class was `w-10` (should be `w-full`) in the source file, and
  `Button`'s default `size` was `fixed` (locks every button to 150px wide).
  Both are corrected here; see the inline comments in
  `components/ui/input.tsx` / `button.tsx` if you want to match the
  original bug-for-bug.
- `CustomColorScheme.tsx` ships 10 named colours (red/green/blue/yellow/
  orange/gray/purple + 3 "TextWhiteBg" variants); production has ~20. Same
  pattern, just add more entries as needed.

## Layout contract (important if you add more pages)

- A page owns **exactly one** `<Workspace tabs={[...]} />`. That's what
  renders the white card and the tab bar.
- `AppShell` must never wrap `children` in a second `<Workspace>` — that
  produces nested scroll containers and a stray horizontal scrollbar (this
  bit us in production; see the comment in `AppShell.tsx`).
- `WorkspaceContent` scrolls internally (`flex-1 min-h-0 overflow-y-auto`).
  Don't add extra fixed heights or nested scroll areas inside a tab's
  content — let the Workspace handle it.

## Dependencies

Trimmed to what this package actually uses — the real app's `package.json`
has ~50 more (PDF export, email parsing, Google APIs, charting, drag-and-drop,
etc.) that aren't relevant to a UI boilerplate. Everything here is either a
Radix primitive (headless, unstyled — shadcn/ui wraps these), a styling
utility (`clsx`, `tailwind-merge`, `class-variance-authority`), or
`react-hook-form` + `zod` for the form example.
