"use client"

import * as React from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { SidebarFooter } from "@/components/ui/sidebar"
import { LogOut, Settings } from "lucide-react"

interface UserProfileFooterProps {
  user: { name: string; email: string; avatarUrl?: string }
}

/** Bottom-of-sidebar user chip with a click-to-open menu (logout/settings). */
export function UserProfileFooter({ user }: UserProfileFooterProps) {
  const [isOpen, setIsOpen] = React.useState(false)
  const containerRef = React.useRef<HTMLDivElement>(null)
  const initials = user.email ? user.email[0].toUpperCase() : "U"

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [])

  return (
    <SidebarFooter className="border-t relative" ref={containerRef}>
      <div
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 py-2 cursor-pointer hover:bg-accent rounded-md transition-colors w-full"
      >
        <Avatar className="h-8 w-8 mr-2">
          <AvatarFallback>{initials}</AvatarFallback>
        </Avatar>
        <div className="flex flex-col flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
          <span className="text-sm font-medium leading-none truncate">{user.name}</span>
          <span className="text-xs text-muted-foreground truncate">{user.email}</span>
        </div>
      </div>
      {isOpen && (
        <div className="absolute bottom-full left-2 right-2 mb-1 bg-white border rounded-md shadow-md overflow-hidden">
          <button className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-accent text-left">
            <Settings className="h-4 w-4" /> Settings
          </button>
          <button className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-accent text-left text-red-600">
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </div>
      )}
    </SidebarFooter>
  )
}
