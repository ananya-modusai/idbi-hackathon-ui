"use client"

import * as React from "react"
import { cn } from "@/lib/utils"
import { useState, useEffect } from "react"
import { WorkspaceContent } from "./WorkspaceContent"
import { WorkspaceTabBar } from "./WorkspaceTabBar"
import { useWorkspace } from "./WorkspaceContext"

interface Tab {
  id: string
  label: string
  content: React.ReactNode
}

interface WorkspaceProps {
  children?: React.ReactNode
  className?: string
  tabs?: Tab[]
  initialActiveTabId?: string
  contentScrollable?: boolean
}

/**
 * The single content shell every page renders exactly once: a white
 * rounded-lg card holding an optional tab bar plus scrollable content.
 *
 * Layout contract (mirrors production — see README):
 *  - A page owns exactly one <Workspace tabs={[...]} />.
 *  - The parent shell (AppShell/AppContent) must NEVER wrap children in a
 *    second <Workspace> — that produces nested scroll containers and a
 *    stray horizontal scrollbar.
 */
export function Workspace({ children, className, tabs, initialActiveTabId, contentScrollable = true }: WorkspaceProps) {
  const { setActiveTab, refreshKey } = useWorkspace()
  const [localActiveTab, setLocalActiveTab] = useState<string | null>(
    initialActiveTabId || tabs?.[0]?.id || null
  )

  useEffect(() => {
    if (!tabs || tabs.length === 0) return
    const exists = localActiveTab ? tabs.some((t) => t.id === localActiveTab) : false
    if (exists) return
    const fallback = (initialActiveTabId && tabs.some((t) => t.id === initialActiveTabId)) ? initialActiveTabId : tabs[0]?.id || null
    if (fallback !== localActiveTab) setLocalActiveTab(fallback)
  }, [tabs, localActiveTab, initialActiveTabId])

  useEffect(() => {
    if (localActiveTab && tabs) {
      const activeTabData = tabs.find((t) => t.id === localActiveTab)
      setActiveTab(localActiveTab, activeTabData?.label || null)
    }
  }, [localActiveTab, setActiveTab, tabs])

  const handleTabChange = React.useCallback((tabId: string) => setLocalActiveTab(tabId), [])

  const activeContent = React.useMemo(() => {
    if (!localActiveTab || !tabs) return null
    const content = tabs.find((t) => t.id === localActiveTab)?.content
    return content ? React.cloneElement(content as React.ReactElement, { key: refreshKey }) : null
  }, [localActiveTab, tabs, refreshKey])

  if (!tabs) {
    return (
      <div className={cn("bg-white rounded-lg overflow-hidden flex flex-col flex-1 min-h-0", className)}>
        {children}
      </div>
    )
  }

  return (
    <div className={cn("bg-white rounded-lg overflow-hidden flex flex-col flex-1 min-h-0", className)}>
      <div className="flex flex-col flex-1 min-h-0 w-full">
        <WorkspaceTabBar tabs={tabs} activeTab={localActiveTab} onTabChange={handleTabChange} />
        <WorkspaceContent key={`${localActiveTab}-${refreshKey}`} content={activeContent} scrollable={contentScrollable} />
      </div>
    </div>
  )
}
