"use client"

import * as React from "react"
import {
  Sidebar,
  SidebarContent as SidebarContentRoot,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
  SidebarHeader,
  SidebarSeparator,
  useSidebar,
} from "@/components/ui/sidebar"
import {
  LineChart,
  Microscope,
  ChevronsLeft,
  ChevronsRight,
  Bell,
  Users,
  Building2,
  Scale,
} from "lucide-react"
import { Montserrat } from "next/font/google"
import { cn } from "@/lib/utils"
import { UserProfileFooter } from "./UserProfileFooter"
import { useWorkspace } from "./WorkspaceContext"

const montserrat = Montserrat({ subsets: ["latin"], weight: ["800"] })

export interface SidebarItem {
  label: string
  icon: React.ComponentType<any>
}

interface SidebarGroupConfig {
  label: string
  items: SidebarItem[]
}

/**
 * Nav model — same shape as production `sidebarGroups` (label + items with
 * an icon), just without the `component`/`href` fields that wire each item
 * to a real page. Swap `onNavigate` for a router.push once real pages exist.
 */
export const sidebarGroups: SidebarGroupConfig[] = [
  {
    label: "Underwriting",
    items: [
      { label: "All Cases", icon: Microscope },
      { label: "Notifications", icon: Bell },
    ],
  },
  {
    label: "Merchant",
    items: [
      { label: "Merchant Report", icon: LineChart },
      { label: "Companies", icon: Building2 },
    ],
  },
  {
    label: "Profiles",
    items: [
      { label: "Users", icon: Users },
      { label: "Compliance & Legal", icon: Scale },
    ],
  },
]

export function AppSidebar({ onNavigate }: { onNavigate?: (group: string, item: string) => void }) {
  const { state } = useSidebar()
  const { activeNavigation, setActiveNavigation, setActiveTab } = useWorkspace()

  const handleItemClick = (group: string, item: SidebarItem) => {
    setActiveTab(null, null)
    setActiveNavigation({ group, item: item.label })
    onNavigate?.(group, item.label)
  }

  return (
    <Sidebar variant="sidebar" collapsible="icon">
      <SidebarHeader className="h-14 relative">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className={cn("transition-all duration-200", "group-data-[collapsible=icon]:opacity-0")}>
            <span className={cn("text-lg text-[#00285B]", montserrat.className)}>modus ai</span>
          </div>
        </div>
        <div className="absolute right-2 top-1/2 -translate-y-1/2">
          <SidebarTrigger>
            {state === "collapsed" ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
          </SidebarTrigger>
        </div>
      </SidebarHeader>
      <SidebarSeparator />
      <SidebarContentRoot>
        {sidebarGroups.map((group, groupIdx) => (
          <SidebarGroup key={`${group.label}-${groupIdx}`}>
            <SidebarGroupLabel>{group.label}</SidebarGroupLabel>
            {group.items.map((item) => {
              const isActive = activeNavigation?.group === group.label && activeNavigation?.item === item.label
              return (
                <SidebarMenuButton
                  key={item.label}
                  icon={item.icon}
                  tooltip={item.label}
                  onClick={() => handleItemClick(group.label, item)}
                  className={cn(isActive && "bg-blue-100/80 text-blue-600 font-medium hover:bg-blue-200/80", "transition-colors")}
                >
                  <span>{item.label}</span>
                </SidebarMenuButton>
              )
            })}
          </SidebarGroup>
        ))}
      </SidebarContentRoot>
      <UserProfileFooter user={{ name: "Demo User", email: "demo@modus.ai" }} />
    </Sidebar>
  )
}
