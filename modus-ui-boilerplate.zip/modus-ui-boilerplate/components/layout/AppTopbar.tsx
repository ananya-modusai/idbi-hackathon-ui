"use client"

import { ChevronRight, RefreshCw } from "lucide-react"
import { useWorkspace } from "./WorkspaceContext"
import { BubbleTag } from "@/components/custom/BubbleTag"

/** Breadcrumb header: "Group > Item > Tab" with a refresh chip when a tab is active. */
export function AppTopbar() {
  const { activeNavigation, activeTab, activeTabLabel, refreshActiveTab } = useWorkspace()

  const handleRefresh = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (activeTab) refreshActiveTab()
  }

  const isHomePage = !activeNavigation?.group && !activeNavigation?.item
  const showTabCrumb = !!activeTabLabel && activeTabLabel !== activeNavigation?.item

  return (
    <header className="border-b bg-white h-14 flex items-center px-6 justify-between gap-4 relative z-40 min-w-0">
      <div className="flex items-center gap-4 min-w-0 flex-1">
        {!isHomePage && (
          <h1 className="flex items-center text-sm font-medium min-w-0">
            <span className="text-muted-foreground hover:text-foreground transition-colors truncate">
              {activeNavigation?.group}
            </span>
            <ChevronRight className="mx-1 h-4 w-4 text-muted-foreground flex-shrink-0" />
            <span className="text-muted-foreground truncate">{activeNavigation?.item}</span>
            {showTabCrumb && (
              <>
                <ChevronRight className="mx-1 h-4 w-4 text-muted-foreground flex-shrink-0" />
                <span className="text-blue-600 truncate">{activeTabLabel}</span>
                <div onClick={handleRefresh} className="ml-3 cursor-pointer flex-shrink-0">
                  <BubbleTag
                    text="Refresh"
                    color="blueTextWhiteBg"
                    hasInsideIcon
                    icon={<RefreshCw className="h-3.5 w-3.5" />}
                    onHover
                    withBorder
                  />
                </div>
              </>
            )}
          </h1>
        )}
      </div>
    </header>
  )
}
