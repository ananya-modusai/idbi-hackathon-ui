"use client"

import * as React from "react"

interface Navigation {
  group: string
  item: string
}

interface WorkspaceContextValue {
  activeNavigation: Navigation | null
  setActiveNavigation: (nav: Navigation | null) => void
  activeTab: string | null
  activeTabLabel: string | null
  setActiveTab: (id: string | null, label: string | null) => void
  refreshKey: number
  refreshActiveTab: () => void
}

const WorkspaceContext = React.createContext<WorkspaceContextValue | null>(null)

/**
 * Minimal stand-in for the production workspaceStore (Zustand). Holds just
 * enough state for the AppTopbar breadcrumb and Workspace tab bar to work:
 * which sidebar item is active, and which tab within that page is active.
 * Swap for Zustand/Redux/etc. once wiring up real navigation.
 */
export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  const [activeNavigation, setActiveNavigation] = React.useState<Navigation | null>(null)
  const [activeTab, setActiveTabState] = React.useState<string | null>(null)
  const [activeTabLabel, setActiveTabLabel] = React.useState<string | null>(null)
  const [refreshKey, setRefreshKey] = React.useState(0)

  const setActiveTab = React.useCallback((id: string | null, label: string | null) => {
    setActiveTabState(id)
    setActiveTabLabel(label)
  }, [])

  const refreshActiveTab = React.useCallback(() => {
    setRefreshKey((k) => k + 1)
  }, [])

  const value = React.useMemo(
    () => ({ activeNavigation, setActiveNavigation, activeTab, activeTabLabel, setActiveTab, refreshKey, refreshActiveTab }),
    [activeNavigation, activeTab, activeTabLabel, setActiveTab, refreshKey, refreshActiveTab]
  )

  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>
}

export function useWorkspace() {
  const ctx = React.useContext(WorkspaceContext)
  if (!ctx) throw new Error("useWorkspace must be used within a WorkspaceProvider")
  return ctx
}
