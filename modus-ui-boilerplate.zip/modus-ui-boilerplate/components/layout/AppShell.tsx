"use client"

import * as React from "react"
import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "./AppSidebar"
import { AppTopbar } from "./AppTopbar"
import { WorkspaceProvider } from "./WorkspaceContext"

/**
 * Top-level app shell: sidebar + topbar + content column.
 *
 * Composition contract (mirrors production, see README "Layout contract"):
 *  - AppShell renders the chrome (sidebar, topbar) and a bg-gray-100 content
 *    slot. It must NEVER wrap `children` in a <Workspace> itself.
 *  - Each page passed as `children` owns exactly one <Workspace tabs={...}/>.
 *    That's what renders the white card + tab bar. A page without it has no
 *    tab bar and the wrong background.
 */
export function AppShell({ children, onNavigate }: { children: React.ReactNode; onNavigate?: (group: string, item: string) => void }) {
  return (
    <WorkspaceProvider>
      <SidebarProvider defaultOpen={true}>
        <div className="flex h-screen w-full overflow-hidden">
          <AppSidebar onNavigate={onNavigate} />
          <div className="flex flex-col flex-1 min-w-0 min-h-0">
            <AppTopbar />
            <div className="flex flex-col flex-1 min-h-0 p-3 bg-gray-100">
              <main className="flex-1 min-h-0 overflow-hidden flex flex-col">
                {children}
              </main>
            </div>
          </div>
        </div>
      </SidebarProvider>
    </WorkspaceProvider>
  )
}
