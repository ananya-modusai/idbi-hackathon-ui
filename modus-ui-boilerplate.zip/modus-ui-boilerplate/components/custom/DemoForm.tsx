"use client"

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const schema = z.object({
  customerName: z.string().min(1, "Required"),
  segment: z.string().min(1, "Required"),
  note: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

/**
 * Reference form pattern: react-hook-form + zod validation, shadcn Input/
 * Select, inline error text under each field. This is the pattern used for
 * every create/edit form in the app (e.g. add-note, edit-limits dialogs).
 */
export function DemoForm({ onSubmit }: { onSubmit?: (values: FormValues) => void }) {
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({ resolver: zodResolver(schema) });

  const segment = watch("segment");

  return (
    <form
      onSubmit={handleSubmit((values) => onSubmit?.(values))}
      className="space-y-4"
    >
      <div className="space-y-1">
        <label className="text-sm font-medium">Customer name</label>
        <Input placeholder="e.g. Priya Patil" {...register("customerName")} />
        {errors.customerName && (
          <p className="text-xs text-destructive">{errors.customerName.message}</p>
        )}
      </div>

      <div className="space-y-1">
        <label className="text-sm font-medium">Segment</label>
        <Select value={segment} onValueChange={(v) => setValue("segment", v, { shouldValidate: true })}>
          <SelectTrigger>
            <SelectValue placeholder="Select segment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="self-employed">Self-Employed</SelectItem>
            <SelectItem value="salaried">Salaried</SelectItem>
            <SelectItem value="nri">NRI</SelectItem>
            <SelectItem value="pensioner">Pensioner</SelectItem>
          </SelectContent>
        </Select>
        {errors.segment && <p className="text-xs text-destructive">{errors.segment.message}</p>}
      </div>

      <div className="space-y-1">
        <label className="text-sm font-medium">Note (optional)</label>
        <Input placeholder="RM notes..." {...register("note")} />
      </div>

      <Button type="submit" size="auto" disabled={isSubmitting}>
        {isSubmitting ? "Saving..." : "Save"}
      </Button>
    </form>
  );
}
