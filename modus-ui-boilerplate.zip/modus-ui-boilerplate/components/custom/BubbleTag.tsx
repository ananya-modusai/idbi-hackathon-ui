import { FC, ReactNode } from 'react';
import { cn } from "@/lib/utils";
import { getColorClasses, getColorClassesWithHover, getBorderColorClass, getTextColorClass, ColorScheme } from './CustomColorScheme';

/**
 * The status-pill / badge primitive used everywhere in the app: NPA status,
 * risk tiers, notification counts, "Refresh" affordances in the topbar, etc.
 * Prefer this over components/ui/badge.tsx when you need a colour token from
 * CustomColorScheme, an icon, or a count bubble.
 */
interface BubbleTagProps {
  hasInsideNumber?: boolean;
  hasInsideIcon?: boolean;
  icon?: ReactNode;
  number?: number;
  text: string;
  color: ColorScheme;
  onHover?: boolean;
  withBorder?: boolean;
  onClick?: () => void;
  clickable?: boolean;
  noBackground?: boolean;
  className?: string;
  size?: 'sm' | 'md';
}

export const BubbleTag: FC<BubbleTagProps> = ({
  hasInsideNumber = false,
  hasInsideIcon = false,
  icon,
  number,
  text,
  color,
  onHover = false,
  withBorder = false,
  onClick,
  clickable = false,
  noBackground = false,
  className,
  size = 'sm',
}) => {
  const handleClick = (e: React.MouseEvent) => {
    if ((clickable || onClick) && onClick) {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    }
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded font-medium justify-center truncate min-w-0",
        size === 'md' ? "px-2.5 py-1 text-sm font-semibold" : "px-2 py-0.5 text-xs",
        noBackground ? getTextColorClass(color) : (onHover || clickable ? getColorClassesWithHover(color) : getColorClasses(color)),
        withBorder ? `border ${getBorderColorClass(color)}` : "",
        (clickable || onClick) ? "cursor-pointer" : "",
        className
      )}
      onClick={handleClick}
      title={text}
    >
      {hasInsideIcon && icon && <span className="flex-shrink-0">{icon}</span>}
      {hasInsideNumber && number !== undefined && <span>{number}</span>}
      <span className="truncate max-w-full">{text}</span>
    </span>
  );
};
