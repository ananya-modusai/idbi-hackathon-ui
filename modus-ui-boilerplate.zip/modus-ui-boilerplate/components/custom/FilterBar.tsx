"use client"

import { FC, useState } from 'react';
import { Check, ChevronDown, X } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';

export interface FilterOption {
  label: string;
  value: string;
  count?: number;
}

interface FilterBarProps {
  /** Blue label rendered to the left of the control. */
  label?: string;
  options: FilterOption[];
  value: string[];
  onChange: (value: string[]) => void;
  placeholder?: string;
  className?: string;
}

/**
 * Multi-select filter dropdown: blue label, checkbox list with per-option
 * count chips, and a compact "N selected" summary on the trigger. Simplified
 * re-implementation of the production MultiSelectFilterBar/SingleSelectFilter
 * pair (which wraps a cmdk-based combobox) so this boilerplate has no cmdk
 * dependency, but the visual language — label, pill trigger, round count
 * chips — matches exactly. See README "Deviations from production".
 */
export const FilterBar: FC<FilterBarProps> = ({
  label,
  options,
  value,
  onChange,
  placeholder = 'Select',
  className,
}) => {
  const [open, setOpen] = useState(false);

  const toggle = (optValue: string) => {
    if (value.includes(optValue)) {
      onChange(value.filter((v) => v !== optValue));
    } else {
      onChange([...value, optValue]);
    }
  };

  const summary =
    value.length === 0
      ? placeholder
      : value.length === 1
      ? options.find((o) => o.value === value[0])?.label ?? placeholder
      : `${value.length} selected`;

  return (
    <div className="flex items-center gap-3 min-w-0">
      {label && (
        <span className="text-sm font-medium text-blue-600 whitespace-nowrap">{label}</span>
      )}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className={cn(
              "flex items-center justify-between gap-2 h-9 min-w-[160px] rounded-md border border-gray-300 bg-inherit px-3 text-sm shadow",
              className
            )}
          >
            <span className="truncate text-left">{summary}</span>
            <span className="flex items-center gap-1 flex-shrink-0">
              {value.length > 0 && (
                <X
                  className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground"
                  onClick={(e) => {
                    e.stopPropagation();
                    onChange([]);
                  }}
                />
              )}
              <ChevronDown className="h-4 w-4 opacity-50" />
            </span>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-64 p-1" align="start">
          <div className="max-h-72 overflow-y-auto">
            {options.map((option) => {
              const checked = value.includes(option.value);
              return (
                <div
                  key={option.value}
                  onClick={() => toggle(option.value)}
                  className="flex items-center gap-2 px-2 py-1.5 rounded-sm text-sm cursor-pointer hover:bg-accent"
                >
                  <Checkbox checked={checked} onCheckedChange={() => toggle(option.value)} />
                  <span className="flex-1 truncate">{option.label}</span>
                  {option.count !== undefined && (
                    <span className="flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-gray-100 text-xs text-gray-600">
                      {option.count}
                    </span>
                  )}
                  {checked && <Check className="h-3.5 w-3.5 text-primary flex-shrink-0" />}
                </div>
              );
            })}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default FilterBar;
