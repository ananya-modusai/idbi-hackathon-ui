"use client"

import { FC } from 'react';
import { Copy } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type IdentifierType = 'ID' | 'CIN' | 'CASE ID' | 'PAN';

interface SecondaryIdOption {
  value: string;
  label: string;
}

interface PageHeaderProps {
  name: string;
  id: string;
  identifierType: IdentifierType;
  secondaryId?: {
    options: SecondaryIdOption[];
    value: string;
    onChange: (value: string) => void;
    label: string;
  };
  actionButton?: React.ReactNode;
}

/**
 * Blue title + "[TYPE id]" chip + copy button, with an optional secondary
 * select and a slot for a page-level action button on the right. Used at the
 * top of every detail/profile screen.
 */
export const PageHeader: FC<PageHeaderProps> = ({ name, id, identifierType, secondaryId, actionButton }) => {
  const copyId = () => {
    navigator.clipboard.writeText(id);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-semibold text-blue-600 leading-none">{name}</h2>
          <div className="flex items-center gap-1 text-sm text-gray-500 leading-none">
            <span>[{identifierType} {id}]</span>
            <button
              onClick={copyId}
              className="text-blue-500 hover:text-blue-700 flex items-center justify-center h-4"
            >
              <Copy className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-4">
          {secondaryId && (
            <div className="flex items-center gap-2">
              {secondaryId.label && (
                <span className="text-sm text-gray-500">{secondaryId.label}:</span>
              )}
              <Select value={secondaryId.value} onValueChange={secondaryId.onChange}>
                <SelectTrigger className="w-[180px] h-8 text-sm">
                  <SelectValue placeholder={`Select ${secondaryId.label}`} />
                </SelectTrigger>
                <SelectContent>
                  {secondaryId.options.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          {actionButton}
        </div>
      </div>
    </div>
  );
};
