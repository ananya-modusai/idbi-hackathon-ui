// Named colour tokens used by BubbleTag/StatCard so every status pill and
// stat card in the app draws from the same fixed palette instead of ad-hoc
// Tailwind classes. Add new entries here rather than hardcoding colors elsewhere.
export const colorSchemes = {
  red: { background: 'bg-red-100', text: 'text-red-700', hover: 'hover:bg-red-200', border: 'border-red-700' },
  green: { background: 'bg-green-100', text: 'text-green-700', hover: 'hover:bg-green-200', border: 'border-green-700' },
  blue: { background: 'bg-blue-100', text: 'text-blue-600', hover: 'hover:bg-blue-200', border: 'border-blue-700' },
  yellow: { background: 'bg-yellow-100', text: 'text-yellow-700', hover: 'hover:bg-yellow-200', border: 'border-yellow-700' },
  orange: { background: 'bg-orange-100', text: 'text-orange-700', hover: 'hover:bg-orange-200', border: 'border-orange-700' },
  gray: { background: 'bg-gray-100', text: 'text-gray-700', hover: 'hover:bg-gray-200', border: 'border-gray-700' },
  purple: { background: 'bg-purple-100', text: 'text-purple-700', hover: 'hover:bg-purple-200', border: 'border-purple-700' },
  blueTextWhiteBg: { background: 'bg-white', text: 'text-blue-700', hover: 'hover:bg-blue-50', border: 'border-blue-700' },
  redTextWhiteBg: { background: 'bg-white', text: 'text-red-700', hover: 'hover:bg-red-50', border: 'border-red-700' },
  greenTextWhiteBg: { background: 'bg-white', text: 'text-green-700', hover: 'hover:bg-green-50', border: 'border-green-700' },
} as const;

export type ColorScheme = keyof typeof colorSchemes;

export const getColorClasses = (color: ColorScheme): string => {
  const scheme = colorSchemes[color];
  return `${scheme.background} ${scheme.text}`;
};

export const getColorClassesWithHover = (color: ColorScheme): string => {
  const scheme = colorSchemes[color];
  return `${scheme.background} ${scheme.text} ${scheme.hover} transition-colors duration-200`;
};

export const getBorderColorClass = (color: ColorScheme): string => colorSchemes[color].border;
export const getTextColorClass = (color: ColorScheme): string => colorSchemes[color].text;
