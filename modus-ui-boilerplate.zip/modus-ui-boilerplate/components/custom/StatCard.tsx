import { FC } from "react";
import { CustomCard } from "@/components/custom/CustomCard";
import { ArrowUpRight } from "lucide-react";
import { ColorScheme, colorSchemes } from "@/components/custom/CustomColorScheme";

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  cardThemeColor?: ColorScheme;
}

/** Small KPI tile: icon + label + value (+ optional up/down trend). Used in
 *  stat-card rows at the top of dashboards and profile pages. */
export const StatCard: FC<StatCardProps> = ({ title, value, icon, trend, cardThemeColor }) => {
  const backgroundClass = cardThemeColor ? colorSchemes[cardThemeColor].background : "bg-white";
  const titleTextColorClass = cardThemeColor ? colorSchemes[cardThemeColor].text : "text-gray-500";
  const valueTextColorClass = cardThemeColor ? colorSchemes[cardThemeColor].text : "text-black";
  const borderStyle = cardThemeColor ? { borderColor: "currentColor", borderWidth: "2px", borderStyle: "solid" as const } : {};

  return (
    <CustomCard className={`p-3 ${backgroundClass} border-2`} style={borderStyle}>
      <div className="flex items-center gap-3">
        <div className="p-1.5 bg-gray-50 rounded-lg">{icon}</div>
        <div className="min-w-0 flex-1">
          <div className={`text-xs truncate ${titleTextColorClass}`}>{title}</div>
          <div className="flex items-center gap-2">
            <div className={`text-base font-semibold truncate ${valueTextColorClass}`}>{value}</div>
            {trend && (
              <div className="flex items-center gap-1">
                <ArrowUpRight
                  className={`h-3 w-3 ${trend.isPositive ? "text-green-500" : "text-red-500"} ${!trend.isPositive && "rotate-90"}`}
                />
                <span className={`text-xs ${trend.isPositive ? "text-green-600" : "text-red-600"}`}>
                  {trend.value}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </CustomCard>
  );
};
