"use client"

import { ReactNode, useState } from "react";
import { PanelRightClose, PanelRightOpen } from "lucide-react";
import { cn } from "@/lib/utils";

interface RightPanelProps {
  title?: string;
  children: ReactNode;
  defaultCollapsed?: boolean;
  className?: string;
}

/**
 * Collapsible right-hand panel — white rounded-lg card that shrinks to a
 * thin rail with a toggle button, matching the production "Artifact" panel
 * behaviour (used for AI report/context panels next to the main workspace).
 * Drop this beside a <Workspace> in a two-column layout.
 */
export function RightPanel({ title, children, defaultCollapsed = false, className }: RightPanelProps) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  return (
    <div
      className={cn(
        "flex-shrink-0 bg-white rounded-lg relative border border-gray-200",
        "transition-[width] duration-300 ease-in-out overflow-hidden",
        collapsed ? "w-10" : "w-full max-w-sm",
        className
      )}
    >
      {collapsed ? (
        <button
          onClick={() => setCollapsed(false)}
          className="w-full h-full flex items-start justify-center pt-3 text-muted-foreground hover:text-foreground"
        >
          <PanelRightOpen className="h-4 w-4" />
        </button>
      ) : (
        <div className="flex flex-col h-full min-h-0">
          <div className="flex items-center justify-between px-4 h-12 border-b shrink-0">
            <span className="text-sm font-medium truncate">{title}</span>
            <button
              onClick={() => setCollapsed(true)}
              className="text-muted-foreground hover:text-foreground"
            >
              <PanelRightClose className="h-4 w-4" />
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto p-4">{children}</div>
        </div>
      )}
    </div>
  );
}
