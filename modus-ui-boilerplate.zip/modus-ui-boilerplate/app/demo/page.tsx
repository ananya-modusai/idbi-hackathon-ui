"use client"

import { useMemo, useState } from "react";
import { Users, Wallet, AlertTriangle, TrendingUp, Plus } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Workspace } from "@/components/layout/Workspace";
import { PageHeader } from "@/components/custom/PageHeader";
import { StatCard } from "@/components/custom/StatCard";
import { BubbleTag } from "@/components/custom/BubbleTag";
import { ToggleTabs } from "@/components/custom/ToggleTabs";
import { FilterBar } from "@/components/custom/FilterBar";
import { DataTable, DataTableColumn } from "@/components/custom/DataTable";
import { RightPanel } from "@/components/custom/RightPanel";
import { DemoForm } from "@/components/custom/DemoForm";
import { Button } from "@/components/ui/button";
import type { ColorScheme } from "@/components/custom/CustomColorScheme";

// ---- fixture data — replace with real API data once wired up ----
interface Lead {
  id: string;
  name: string;
  segment: string;
  rating: string;
  exposure: number;
  riskTier: "Clean" | "Watch" | "Stressed" | "Default";
}

const LEADS: Lead[] = [
  { id: "CU-1001", name: "Ananya Rao", segment: "Self-Employed", rating: "A+", exposure: 7390224, riskTier: "Clean" },
  { id: "CU-1002", name: "Rohan Mehta", segment: "Salaried", rating: "A", exposure: 4326565, riskTier: "Watch" },
  { id: "CU-1003", name: "Kavya Iyer", segment: "NRI", rating: "AA", exposure: 4756747, riskTier: "Clean" },
  { id: "CU-1004", name: "Devansh Patel", segment: "HUF", rating: "A", exposure: 3270802, riskTier: "Stressed" },
  { id: "CU-1005", name: "Meera Nair", segment: "Pensioner", rating: "B", exposure: 5234319, riskTier: "Default" },
  { id: "CU-1006", name: "Aarav Sharma", segment: "Self-Employed", rating: "BBB", exposure: 1980000, riskTier: "Watch" },
];

const RISK_COLOR: Record<Lead["riskTier"], ColorScheme> = {
  Clean: "green",
  Watch: "yellow",
  Stressed: "orange",
  Default: "red",
};

function formatINR(n: number) {
  return `₹${(n / 100000).toFixed(1)}L`;
}

function OverviewTab() {
  const [tierFilter, setTierFilter] = useState<string[]>([]);
  const [view, setView] = useState("table");
  const [showForm, setShowForm] = useState(false);

  const filtered = useMemo(
    () => (tierFilter.length === 0 ? LEADS : LEADS.filter((l) => tierFilter.includes(l.riskTier))),
    [tierFilter]
  );

  const columns: DataTableColumn<Lead>[] = [
    { key: "id", header: "Customer ID", render: (r) => <span className="font-mono text-xs">{r.id}</span>, sortValue: (r) => r.id },
    { key: "name", header: "Name", render: (r) => r.name, sortValue: (r) => r.name },
    { key: "segment", header: "Segment", render: (r) => r.segment, sortValue: (r) => r.segment },
    { key: "rating", header: "Rating", render: (r) => r.rating, sortValue: (r) => r.rating },
    {
      key: "exposure", header: "Exposure", align: "right",
      render: (r) => formatINR(r.exposure), sortValue: (r) => r.exposure,
    },
    {
      key: "riskTier", header: "Risk Tier", align: "center",
      render: (r) => <BubbleTag text={r.riskTier} color={RISK_COLOR[r.riskTier]} />,
      sortValue: (r) => r.riskTier,
    },
  ];

  return (
    <div className="flex gap-4 flex-1 min-h-0">
      <div className="flex flex-col flex-1 min-w-0 gap-4">
        <PageHeader
          name="Lead Prioritization"
          id="CRM-2026-09"
          identifierType="ID"
          actionButton={
            <Button size="sm" onClick={() => setShowForm((s) => !s)}>
              <Plus className="h-4 w-4" /> New note
            </Button>
          }
        />

        <div className="grid grid-cols-4 gap-3">
          <StatCard title="Total Leads" value={String(LEADS.length)} icon={<Users className="h-4 w-4 text-blue-600" />} />
          <StatCard
            title="Total Exposure"
            value={formatINR(LEADS.reduce((s, l) => s + l.exposure, 0))}
            icon={<Wallet className="h-4 w-4 text-green-600" />}
            trend={{ value: "+4.2%", isPositive: true }}
          />
          <StatCard
            title="At Risk"
            value={String(LEADS.filter((l) => l.riskTier === "Default" || l.riskTier === "Stressed").length)}
            icon={<AlertTriangle className="h-4 w-4 text-red-600" />}
            cardThemeColor="red"
          />
          <StatCard
            title="Hot Leads"
            value={String(LEADS.filter((l) => l.riskTier === "Clean").length)}
            icon={<TrendingUp className="h-4 w-4 text-blue-600" />}
            cardThemeColor="blue"
          />
        </div>

        {showForm && (
          <div className="border rounded-lg p-4 bg-white">
            <DemoForm onSubmit={(v) => { console.log(v); setShowForm(false); }} />
          </div>
        )}

        <div className="flex items-center justify-between">
          <FilterBar
            label="Risk Tier"
            options={[
              { label: "Clean", value: "Clean", count: LEADS.filter((l) => l.riskTier === "Clean").length },
              { label: "Watch", value: "Watch", count: LEADS.filter((l) => l.riskTier === "Watch").length },
              { label: "Stressed", value: "Stressed", count: LEADS.filter((l) => l.riskTier === "Stressed").length },
              { label: "Default", value: "Default", count: LEADS.filter((l) => l.riskTier === "Default").length },
            ]}
            value={tierFilter}
            onChange={setTierFilter}
            placeholder="All tiers"
          />
          <ToggleTabs
            value={view}
            onValueChange={setView}
            options={[{ value: "table", label: "Table" }, { value: "chart", label: "Chart" }]}
          />
        </div>

        {view === "table" ? (
          <DataTable columns={columns} data={filtered} rowKey={(r) => r.id} />
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground border rounded-lg bg-white min-h-[200px]">
            Chart view placeholder — wire up recharts here
          </div>
        )}
      </div>

      <RightPanel title="Suggested Actions">
        <div className="space-y-3 text-sm">
          <p className="text-muted-foreground">
            Highest-priority lead this week:
          </p>
          <div className="border rounded-md p-3">
            <div className="font-medium">Ananya Rao</div>
            <div className="text-xs text-muted-foreground mb-2">Self-Employed &middot; A+ rating</div>
            <BubbleTag text="Working capital cross-sell" color="blue" size="md" />
          </div>
          <Button size="sm" variant="outline" className="w-full">
            View full profile
          </Button>
        </div>
      </RightPanel>
    </div>
  );
}

function NotesTab() {
  return (
    <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground border rounded-lg bg-white min-h-[200px]">
      Second tab — demonstrates the Workspace tab bar. Put any content here.
    </div>
  );
}

export default function DemoPage() {
  return (
    <AppShell>
      <Workspace
        tabs={[
          { id: "overview", label: "Overview", content: <OverviewTab /> },
          { id: "notes", label: "Notes", content: <NotesTab /> },
        ]}
      />
    </AppShell>
  );
}
