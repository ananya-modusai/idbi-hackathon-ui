import type { Metadata } from "next";
import { Inter, Montserrat } from "next/font/google";
import "./globals.css";

// Real product uses local Geist woff files for body text + Montserrat 800 for the
// sidebar wordmark. Inter is swapped in here as a free, visually-close Google Font
// so this boilerplate has zero binary asset dependencies — see README "Fonts".
const inter = Inter({ subsets: ["latin"], variable: "--font-body" });
const montserrat = Montserrat({ subsets: ["latin"], weight: ["800"], variable: "--font-wordmark" });

export const metadata: Metadata = {
  title: "Modus UI Boilerplate",
  description: "App-shell + design-system boilerplate for building demo screens",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${montserrat.variable}`}>
      <body className={inter.className}>{children}</body>
    </html>
  );
}
