import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="h-screen w-full flex flex-col items-center justify-center gap-4 bg-gray-50">
      <h1 className="text-2xl font-semibold text-[#00285B]">modus ai — UI boilerplate</h1>
      <p className="text-muted-foreground max-w-md text-center text-sm">
        App shell, design-system components, and one working demo screen. See the README for what's included.
      </p>
      <Link href="/demo">
        <Button size="lg">Open demo screen</Button>
      </Link>
    </div>
  );
}
